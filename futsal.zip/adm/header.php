	<div class="navbar-inner" style="border:0px solid #bbb; border-radius:10px; padding:10px 20px 10px 20px; margin-top:5px; margin-bottom:5px; margin-left:auto; margin-right:auto;">
		<div style="margin-top:2px; margin-bottom:2px; margin-left:auto; margin-right:auto;">
        	<a href="index.php">
            <table border="0" cellpadding="5" cellspacing="0" align="left">
                <tr>
                	<td width="15%" align="center">
                    	&nbsp;
					</td>
					<td width="85%" align="left">
                    	<font face="Comic Sans MS, cursive" color="#FF0000"><h3>Login Admin</h3></font>
					</td>
				</tr>
			</table>
			</a>
		</div>
	</div>