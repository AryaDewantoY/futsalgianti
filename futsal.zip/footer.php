<div class="navbar-fixed-bottom">
    <div class="navbar-inner">
		<div class="text-center text-error">
        	<small>Copyright &copy; 2017</small>
        </div>
        <div class="text-center text-error">
        	<b>Aplikasi Pemesanan Lapangan Futsal Online. &reg;</b>
        </div>
    </div>
</div>